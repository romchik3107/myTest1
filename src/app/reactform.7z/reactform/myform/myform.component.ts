import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormArray, FormBuilder } from '@angular/forms';
import { Group } from './class/group';
import { Validators } from '@angular/forms';
import { validatorTerm } from './service/ValidatorTerm';

import { AlertController } from '@ionic/angular';
import { validatorCredits } from './service/ValidatorCredits';
import { ValidatorTermService } from './service/ValidatorTerm.service';
import { ValidatorCreditsService } from './service/ValidatorCredits.service';
@Component({
  selector: 'app-myform',
  templateUrl: './myform.component.html',
  styleUrls: ['./myform.component.scss'],
})
export class MyformComponent implements OnInit {
  GroupForm!:FormGroup;
  Group!: Group;


  constructor(private fb:FormBuilder, private alertController: AlertController) {
    this.GroupForm = this.fb.group({
        GroupName: ['', [Validators.required]],
        GroupNumberOfCredits: ['', [Validators.required]],
        GroupTeacherName:['', [Validators.required]],
        GroupRank:['', [Validators.required]],
        GroupTerm:['', [validatorTerm()]],
        groups: new FormArray([new FormControl()]),
      })
   }

  // Додавання предмета
  addGroup() {
    console.log("Add"); 
    (this.GroupForm.controls['groups'] as FormArray).push(
      new FormControl()
      )
  }
  // Видалення предмета
  deleteGroup(i: any) {
    console.log('Delete');
    (this.GroupForm.controls['groups'] as FormArray).removeAt(i)
  }
  // Повертаємо список контролів як FormArray
  getControls() { return (this.GroupForm.get('groups') as FormArray).controls; }
  // Збереження форми
  onSubmit() { 
    // let d1 = this.GroupForm.value.GroupTerm;

    // let valid_01 = new ValidatorTermService(); 
    // if (valid_01.validateTerm(d1)) 
    //   console.log("Submit"); 
    // else
    //   this.presentAlert("Неправильно!!!");



      let d2 = this.GroupForm.value.GroupNumberOfCredits;
      let valid_02 = new ValidatorCreditsService(); 
      if (valid_02.validateNumberOfCredits(d2)) 
        console.log("Submit"); 
      else
        this.presentAlert("Неправильно!!!");
  }

  async presentAlert(message: string) {
    const alert = await this.alertController.create({
      header: 'Помилка',
      subHeader: '',
      message: message,
      buttons: ['OK']
    });
    await alert.present();
  }

  ngOnInit() {}
}
